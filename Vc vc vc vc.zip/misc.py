

HELP_TEXT = """__𝙄 𝘾𝙖𝙣 𝙋𝙡𝙖𝙮 𝙈𝙪𝙨𝙞𝙘 𝙄𝙣 𝙏𝙝𝙚 𝙑𝙤𝙞𝙘𝙚 𝘾𝙝𝙖𝙩 __

**/help** __Show This Message.__
**/skip** __Skip The Current Playing Music.__
**/play** __youtube/saavn/deezer Song_Name__
**/telegram** __Play From Telegram Audio.__
**/joinvc** __Join Voice Chat.__
**/leavevc** __Leave Voice Chat.__
**/volume [1-200]** __Adjust Volume.__
**/pause** __Pause Music.__
**/resume** __Resume Music.__
**/update** __Update & Restart.__"""

START_TEXT = "__𝙃𝙞 𝙄𝙢 𝙑𝙤𝙞𝙘𝙚 𝘾𝙝𝙖𝙩 𝙈𝙪𝙨𝙞𝙘 𝘽𝙤𝙩 , 𝙋𝙤𝙬𝙚𝙧𝙙 𝘽𝙮 𝙈𝙧 𝙈𝙚𝙩𝙞 𝙏𝙖𝙗𝙧𝙞𝙯𝙞 : @Metiwz __"

REPO_TEXT = (
    "[Channel](https://t.me/Metiwz_Team)"
    + " | [Group](t.me/Metiwz_Team)"
)

